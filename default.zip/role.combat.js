const TARGET_ROOM = "W9N9";
var roleCombat = {
    run: function(creep) {
        var target;
        if (creep.room.name != TARGET_ROOM) {
            target = creep.pos.findClosestByPath(creep.room.findExitTo(TARGET_ROOM));
            if (target) {
                creep.moveTo(target);
            }
            return;
        }
        
        target = creep.pos.findClosestByRange([FIND_HOSTILE_CREEPS, FIND_HOSTILE_SPAWNS]);
        console.log(target)
        if (target) {
            if (creep.attack(target) == ERR_NOT_IN_RANGE) {
                creep.moveTo(target);
            }
        } 
    }
}
module.exports = roleCombat;