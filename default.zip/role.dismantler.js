const TARGET_ROOM = "W9N9";
var roleDismantler = {
    run: function(creep) {
        var target;
        if (creep.room.name != TARGET_ROOM) {
            console.log(creep.room.name)
            target = creep.pos.findClosestByPath(creep.room.findExitTo(TARGET_ROOM));
            if (target) {
                creep.moveTo(target);
            }
        }
        
        target = creep.pos.findClosestByRange([FIND_HOSTILE_STRUCTURES, FIND_HOSTILE_CONSTRUCTION_SITES]);
        console.log(target)
        if (target) {
            if (creep.dismantle(target) == ERR_NOT_IN_RANGE) {
                creep.moveTo(target);
            }
        } 
    }
}
module.exports = roleDismantler;