var roleHarvester = require('role.harvester');
var roleUpgrader = require('role.upgrader');
var roleBuilder = require('role.builder');
var roleScout = require('role.scout');
var roleBigHarvester = require('role.bigHarvester');
var roleCombat = require('role.combat');
var roleDefense = require('role.defense');
var roleDismantler = require('role.dismantler');

const SPAWN_NAME = "epicSpawn3";

module.exports.loop = function() {
    for (var name in Memory.creeps) {
        if (!Game.creeps[name]) {
            delete Memory.creeps[name];
            //console.log('Clearing non-existing creep memory:', name);
        }
    }

    var upgraders = _.filter(Game.creeps, (creep) => creep.memory.role == 'upgrader');
    //console.log('Upgraders: ' + upgraders.length);
    if (upgraders.length < 1) {
        var newName = `Upgrader${Game.time}`;
        //console.log('Spawning new upgrader: ' + newName);
        Game.spawns[SPAWN_NAME].spawnCreep([WORK, CARRY, MOVE], newName, {
            memory: {
                role: 'upgrader'
            }
        });
    }
    
    var dismantlers = _.filter(Game.creeps, (creep) => creep.memory.role == 'dismantler');
    //console.log('Dismantler: ' + dismantlers.length);
    if (dismantlers.length < 2) {
        var newName = `Dismantler${Game.time}`;
        //console.log('Spawning new dismantler: ' + newName);
        Game.spawns[SPAWN_NAME].spawnCreep([WORK, CARRY, MOVE], newName, {
            memory: {
                role: 'dismantler'
            }
        });
    }
    
    var combats = _.filter(Game.creeps, (creep) => creep.memory.role == 'combat');
    //console.log('Combats: ' + combats.length);
    if (combats.length < 2) {
        var newName = `Combat${Game.time}`;
        //console.log('Spawning new combat: ' + newName);
        Game.spawns[SPAWN_NAME].spawnCreep([ATTACK, ATTACK, MOVE], newName, {
            memory: {
                role: 'combat'
            }
        });
    }
    
    var defenses = _.filter(Game.creeps, (creep) => creep.memory.role == 'defense');
    //console.log('Defense: ' + defenses.length);
    if (defenses.length < 2) {
        var newName = `Defense${Game.time}`;
        //console.log('Spawning new defense: ' + newName);
        Game.spawns[SPAWN_NAME].spawnCreep([ATTACK, ATTACK, MOVE], newName, {
            memory: {
                role: 'defense'
            }
        });
    }

    var builders = _.filter(Game.creeps, (creep) => creep.memory.role == 'builder');
    //console.log('Builders: ' + builders.length);
    if (builders.length < 4) {
        var newName = `Builder${Game.time}`;
        //console.log('Spawning new builder: ' + newName);
        Game.spawns[SPAWN_NAME].spawnCreep([WORK, CARRY, MOVE], newName, {
            memory: {
                role: 'builder'
            }
        });
    }

    var harvesters = _.filter(Game.creeps, (creep) => creep.memory.role == 'harvester');
    //console.log('Harvesters: ' + harvesters.length);
    if (harvesters.length < 2) {
        var newName = `Harvester${Game.time}`;
        //console.log('Spawning new harvester: ' + newName);
        Game.spawns[SPAWN_NAME].spawnCreep([WORK, CARRY, MOVE], newName, {
            memory: {
                role: 'harvester'
            }
        });
    }

    /* var scouts = _.filter(Game.creeps, (creep) => creep.memory.role == 'scout');
     //console.log('Scouts: ' + scouts.length);
     if(scouts.length < 1) {
         var newName = `Scout${Game.time}`;
         //console.log('Spawning new scout: ' + newName);
         Game.spawns[SPAWN_NAME].spawnCreep([MOVE,MOVE,MOVE,MOVE], newName,
             {memory: {role: 'scout'}});
     }*/

    var bigHarvesters = _.filter(Game.creeps, (creep) => creep.memory.role == 'bigHarvester');
    //console.log('Big Harvester: ' + bigHarvesters.length);
    if (harvesters.length == 2 && upgraders.length == 1 && bigHarvesters.length < 1) {
        var newName = `Big Harvester${Game.time}`;
        //console.log('Spawning new bigHarvester: ' + newName);
        Game.spawns[SPAWN_NAME].spawnCreep([MOVE, MOVE, WORK, WORK, CARRY, CARRY], newName, {
            memory: {
                role: 'bigHarvester'
            }
        });
    }

    if (Game.spawns[SPAWN_NAME].spawning) {
        var spawningCreep = Game.creeps[Game.spawns[SPAWN_NAME].spawning.name];
        Game.spawns[SPAWN_NAME].room.visual.text(
            '🛠️' + spawningCreep.memory.role,
            Game.spawns[SPAWN_NAME].pos.x + 1,
            Game.spawns[SPAWN_NAME].pos.y, {
                align: 'left',
                opacity: 0.8
            });
    }
    for (var name in Game.creeps) {
        var creep = Game.creeps[name];
        switch (creep.memory.role) {
            case 'harvester': roleHarvester.run(creep); break;
            case 'upgrader': roleUpgrader.run(creep); break;
            case 'builder': roleBuilder.run(creep); break;
            case 'scout': roleScout.run(creep); break;
            case 'bigHarvester': roleBigHarvester.run(creep); break;
            case 'combat': roleCombat.run(creep); break;
            case 'defense': roleDefense.run(creep); break;
            case 'dismantler': roleDismantler.run(creep); break;
            default: console.log("<I>Unknown role detected</I>");
        }
    }
}