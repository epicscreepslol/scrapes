var roleNull = {
    run: function(creep) {
        
    }
}
module.exports = roleNull;